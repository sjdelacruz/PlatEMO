function [Population,Rank,Dis] = EnvironmentalSelection(Population,W,N)
% The environmental selection of Constrained MaOEA/IGD

%------------------------------- Copyright --------------------------------
% Copyright (c) 2021 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    %% Assign proximity distance
    [~,x]      = unique(round(Population.objs*1e4)/1e4,'rows');
    Population = Population(x);
    N          = min(N,length(Population));
    Rank = zeros(1,length(Population));
    Dis  = zeros(length(Population),size(W,1));
    
    %CV = sum(max(0,Population.cons),2); %Constraint violation sum for each solution 
    
    for i = 1 : length(Population) 
        %   if CV(i) == 0 %Considering feasibility for the original scheme
        temp = repmat(Population(i).obj,size(W,1),1);
        domi = any(temp<W,2) - any(temp>W,2);
        if any(domi==1)
            Rank(i)  = 1;
            Dis(i,:) = -sqrt(sum((temp-W).^2,2))';
        elseif any(domi==-1)
            Rank(i)  = 3;
            Dis(i,:) = sqrt(sum((temp-W).^2,2))';
        else
            Rank(i)  = 2;
            Dis(i,:) = sqrt(sum(max(temp-W,0).^2,2))';
        end
        %  else
        %     Rank(i)  = 4;
        %    temp = repmat(Population(i).obj,size(W,1),1);
        %   Dis(i,:) = sqrt(sum(max(temp-W,0).^2,2))';
    %end
    end

    %% Select the solutions in the first fronts
    MaxFNo = find(cumsum(hist(Rank,1:3))>=N,1);
    
    %Considering the new rule, select solutions based on the maxfront found
    %MaxFNo = find(cumsum(hist(Rank,1:4))>=N,1); 
    Next   = Rank < MaxFNo;
    
    %% Select the solutions in the last front
    Last   = find(Rank==MaxFNo);
   
    %Choose = LastSelection(Dis(Last,:),N-sum(Next),W);
    %=====================================================================
    %%%                Choose considering feasibility
    Zmin = min(Population(all(Population.cons<=0,2)).objs,[],1);
    if isempty(Zmin)
        Zmin = ones(1,size(W,2));
    end
    
    %Choose = LastSelection(Dis(Last,:),N-sum(Next),W);
    Choose = LastSelectionBasedNSGAIII(Population(Next).objs,Population(Last).objs,N-sum(Next),W,Zmin);

    Next(Last(Choose)) = true;
    % Population for next generation
    Population = Population(Next);
    Rank       = Rank(Next);
    Dis        = Dis(Next,:);
end

function Choose = LastSelection(Dis,K,W)
% Select part of the solutions in one front

    %% Select K points from W
    Distance = pdist2(W,W);
    Distance(logical(eye(length(Distance)))) = inf;
    Del = false(1,size(W,1));
    while sum(~Del) > K
        Remain   = find(~Del);
        Temp     = sort(Distance(Remain,Remain),2);
        [~,Rank] = sortrows(Temp);
        Del(Remain(Rank(1))) = true;
    end
    Dis = Dis(:,~Del);
    
    if false
        %% Hungarian method based selection
        Choose = Assignmentoptimal(Dis'-min(Dis(:)));
    else
        %% Greedy algorithm based selection (more efficient)
        Choose = false(1,size(Dis,1));
        for i = 1 : size(Dis,2)
            remain   = find(~Choose);
            [~,best] = min(Dis(remain,i));
            Choose(remain(best)) = true;
        end
    end
end

function Choose = LastSelectionBasedNSGAIII(PopObj1,PopObj2,K,Z,Zmin)
% Select part of the solutions in the last front

    PopObj = [PopObj1;PopObj2] - repmat(Zmin,size(PopObj1,1)+size(PopObj2,1),1);
    [N,M]  = size(PopObj);
    N1     = size(PopObj1,1);
    N2     = size(PopObj2,1);
    NZ     = size(Z,1);

    %% Normalization
    % Detect the extreme points
    Extreme = zeros(1,M);
    w       = zeros(M)+1e-6+eye(M);
    for i = 1 : M
        [~,Extreme(i)] = min(max(PopObj./repmat(w(i,:),N,1),[],2));
    end
    % Calculate the intercepts of the hyperplane constructed by the extreme
    % points and the axes
    Hyperplane = PopObj(Extreme,:)\ones(M,1);
    a = 1./Hyperplane;
    if any(isnan(a))
        a = max(PopObj,[],1)';
    end
    % Normalization
    PopObj = PopObj./repmat(a',N,1);
    
    %% Associate each solution with one reference point
    % Calculate the distance of each solution to each reference vector
    Cosine   = 1 - pdist2(PopObj,Z,'cosine');
    Distance = repmat(sqrt(sum(PopObj.^2,2)),1,NZ).*sqrt(1-Cosine.^2);
    % Associate each solution with its nearest reference point
    [d,pi] = min(Distance',[],1);

    %% Calculate the number of associated solutions except for the last front of each reference point
    rho = hist(pi(1:N1),1:NZ);
    
    %% Environmental selection
    Choose  = false(1,N2);
    Zchoose = true(1,NZ);
    % Select K solutions one by one
    while sum(Choose) < K
        % Select the least crowded reference point
        Temp = find(Zchoose);
        Jmin = find(rho(Temp)==min(rho(Temp)));
        j    = Temp(Jmin(randi(length(Jmin))));
        I    = find(Choose==0 & pi(N1+1:end)==j);
        % Then select one solution associated with this reference point
        if ~isempty(I)
            if rho(j) == 0
                [~,s] = min(d(N1+I));
            else
                s = randi(length(I));
            end
            Choose(I(s)) = true;
            rho(j) = rho(j) + 1;
        else
            Zchoose(j) = false;
        end
    end
end